class settings_struct {
  videoElement = null;
  audioElement = null;
  musicVolume = 0.9;
  description_Texts = ['hittas.net , s3x'];
}

const settings = new settings_struct();